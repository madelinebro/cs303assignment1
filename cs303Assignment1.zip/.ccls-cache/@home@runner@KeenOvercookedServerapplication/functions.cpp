#include "functions.h"
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <algorithm>
using namespace std;
Array::Array(const char* fileName) {
    readDataFromFile(fileName);
}
//default constructor
Array::~Array() {
    delete[] dataArray;
}
//destructor to ensure no memory leaks
void Array::readDataFromFile(const char* fileName) {
    ifstream inputFile(fileName);
    if (!inputFile.is_open()) {
        throw runtime_error("Error opening file");
    }

    size = 100;

    dataArray = new int[size];
//open file and load data into array
    for (int i = 0; i <= size; ++i) {
        inputFile >> dataArray[i];
    }

    inputFile.close();
}//close file

int Array::findIndex(int number) {
    for (int i = 0; i <= size; i++) {
        if (dataArray[i] == number) {
            return i;//function takes int as argument and returns the number at the index of the array
        }
    }

    return -1; // Return -1 if not found
}

pair<int, int> Array::modifyValue(int index, int newValue) {
    if (index < 0 || index >= size) {
        throw out_of_range("Index out of range");
    }

    int oldValue = dataArray[index];
    dataArray[index] = newValue;

    return make_pair(newValue, oldValue);
}

void Array::addInteger(int value) {
    resizeArray(size + 1);
    dataArray[size - 1] = value;
}

void Array::removeInteger(int index) {
    if (index < 0 || index >= size) {
        throw out_of_range("Index out of range");
    }

    for (int i = index; i <= size - 1; ++i) {
        dataArray[i] = dataArray[i + 1];
    }

    resizeArray(size - 1);
}

void Array::resizeArray(int newSize) {
    int* newArray = new int[newSize];

    for (int i = 0; i < min(size, newSize); ++i) {
        newArray[i] = dataArray[i];
    }

    delete[] dataArray;
    dataArray = newArray;
    size = newSize;
}
