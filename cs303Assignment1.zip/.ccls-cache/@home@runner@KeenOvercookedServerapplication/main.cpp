#include <iostream>
#include "functions.h"

using  namespace std;

int main() {
    const char* fileName = "A1input.txt";
  //open file

    try {//try loading data with file and catch any errors
        Array array(fileName);
        int input;
        cout << "Enter an integer to search for: ";
        cin >> input;
        int numberToFind = input;
        int index = array.findIndex(numberToFind);
        if (index != -1) {
            cout << "Number " << numberToFind << " found at index: " << index << endl;
        } else {
            cout << "Number " << numberToFind << " not found in the array." << endl;
        }

        int modifyIndex, newValue;
        cout << "Enter index to modify: ";
        cin >> modifyIndex;
        cin >> newValue;
        try {
            auto result = array.modifyValue(modifyIndex, newValue);
            cout << "Modified value at index " << modifyIndex << ". Old value: "
                      << result.second << ", New value: " << result.first << endl;
        } catch (const out_of_range& e) {
            cerr << "Error modifying value: " << e.what() << endl;
        }

        int valueToAdd;
        cout << "Enter value to add: ";
        cin >> valueToAdd;

        array.addInteger(valueToAdd);
        cout << "Added value " << valueToAdd << " to the end of the array." << endl;

        int indexToRemove;
        cout << "Enter index to remove or replace with 0: ";
        cin >> indexToRemove;

        try {
            array.removeInteger(indexToRemove); 
            cout << "Replaced value at index " << indexToRemove << " with 0 in the array." << endl;
        } catch (const out_of_range& e) {
            cerr << "Error replacing/removing value: " << e.what() << endl;
        }

    } catch (const runtime_error& e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
