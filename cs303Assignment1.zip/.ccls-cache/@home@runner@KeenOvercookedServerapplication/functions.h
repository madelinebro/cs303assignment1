#include <utility>  

using namespace std;
//declare array as a class
class Array {
public:
    Array(const char* fileName);
    ~Array();

    int findIndex(int number);
    pair<int, int> modifyValue(int index, int newValue);
    void addInteger(int value);
    void removeInteger(int index);

private:
    int* dataArray;
    int size;

    void readDataFromFile(const char* fileName);
    void resizeArray(int newSize);
};
